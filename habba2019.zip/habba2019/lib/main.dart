import 'package:flutter/material.dart';
import 'package:habba2019/screens/home_screen.dart';
import 'package:firebase_messaging/firebase_messaging.dart';


void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  MyAppState createState() {
    return new MyAppState();
  }
}

class MyAppState extends State<MyApp> {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();

  @override
  void initState() {
    super.initState();
    _firebaseMessaging.getToken().then((token) => print(token));
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Habba 2019',
      theme: new ThemeData(
        textSelectionColor: Colors.grey,
        textSelectionHandleColor: Colors.black38,
        cursorColor: Colors.black45,
        primarySwatch: Colors.grey,
        fontFamily: 'ProductSans',
        primaryColor: Colors.grey,
      ),
      home: HomeScreen(),
    );
  }
}

